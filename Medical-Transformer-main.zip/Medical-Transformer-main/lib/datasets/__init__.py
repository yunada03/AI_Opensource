from .imagenet1k import imagenet1k


__all__ = ['imagenet1k']
